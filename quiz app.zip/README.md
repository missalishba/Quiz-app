# Quiz Application

An interactive quiz platform with user authentication, featuring multiple programming quizzes.

## Features

- User registration and authentication
- Multiple quiz categories
- Real-time scoring
- User profiles
- Responsive design

## Setup

### Prerequisites

- Node.js (v14 or higher)
- MongoDB (local or cloud)

### Installation

1. Clone the repository:

```
git clone <repository-url>
cd quiz-app
```

2. Install dependencies:

```
npm install
```

3. Set up environment variables:
   - Create a `.env` file in the `server` directory with the following content:
   ```
   PORT=5000
   MONGO_URI=mongodb://localhost:27017/quiz-app
   JWT_SECRET=your_jwt_secret_key_here
   ```
   Replace the MONGO_URI with your MongoDB connection string if using MongoDB Atlas.
   Replace the JWT_SECRET with a secure random string.

## Running the Application

### Development Mode

1. Start the backend server:

```
npm run server
```

2. Start the frontend server:

```
npm run client
```

3. To run both concurrently:

```
npm run dev
```

### Production Mode

1. Build the frontend (if using a build process):

```
cd frontend
npm run build
```

2. Start the server:

```
npm start
```

## Directory Structure

- `server/` - Backend Node.js/Express application
  - `controllers/` - Request handlers
  - `models/` - Database models
  - `middleware/` - Express middleware
  - `routes/` - API routes
- `frontend/` - Frontend application
  - HTML, CSS, and JavaScript files

## API Endpoints

### Authentication

- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Login and get authentication token

## License

This project is licensed under the MIT License - see the LICENSE file for details.
